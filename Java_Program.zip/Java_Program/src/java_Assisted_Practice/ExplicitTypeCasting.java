package java_Assisted_Practice;

public class ExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a = 36.256;
		int b = (int)a;
		System.out.println(b);

	}

}

