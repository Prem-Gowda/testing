package java_Assisted_Practice;

public class DoWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		do {
			System.out.println("Today is Wednesday");
			i++;
		}while(i<=7);
		System.out.println("I am out of the loop");
		

	}
	

}
