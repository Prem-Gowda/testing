package inheritance;

public class Access1 {
	int hours =3;
	int mins = 38;
	public String name = "Prem";
	public String tool = "Selenium";
	private int a =3;
	private int b = 85;
	protected int x = 100;
	protected int z = 200;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
