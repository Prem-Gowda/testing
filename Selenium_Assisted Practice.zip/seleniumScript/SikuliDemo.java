package seleniumScript;

public class SikuliDemo {

}
