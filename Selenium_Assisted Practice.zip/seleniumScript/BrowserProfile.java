package seleniumScript;

public class BrowserProfile {

}
